$(document).ready(function() {  

    // sidebar navigation
    $('#main-menu').metisMenu();

});