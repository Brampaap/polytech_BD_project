<?php
$login = "std_1257";
$password = "test111111";
$dbh = new PDO('mysql:host=std-mysql;port=3306;dbname=std_1257', $login, $password);
?> 
